// src/components/Contact.jsx
import { motion } from "framer-motion";
import { useState } from "react";
import { FiSend } from "react-icons/fi";

const Contact = () => {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Message sent successfully! 🚀"); // Placeholder for EmailJS or backend
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <div id="contact" className="w-full py-20 px-6 bg-black text-white">
      <motion.div
        className="max-w-3xl mx-auto"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h2 className="text-4xl font-bold text-purple-400 text-center mb-10">Get in Touch</h2>
        <form onSubmit={handleSubmit} className="flex flex-col gap-6">
          <input
            type="text"
            name="name"
            placeholder="Your Name"
            value={formData.name}
            onChange={handleChange}
            required
            className="p-3 rounded bg-gray-800 text-white border border-gray-600 focus:outline-purple-500"
          />
          <input
            type="email"
            name="email"
            placeholder="Your Email"
            value={formData.email}
            onChange={handleChange}
            required
            className="p-3 rounded bg-gray-800 text-white border border-gray-600 focus:outline-purple-500"
          />
          <textarea
            name="message"
            rows="5"
            placeholder="Your Message"
            value={formData.message}
            onChange={handleChange}
            required
            className="p-3 rounded bg-gray-800 text-white border border-gray-600 focus:outline-purple-500"
          ></textarea>
          <button
            type="submit"
            className="flex items-center gap-3 justify-center bg-purple-600 hover:bg-purple-700 px-6 py-3 text-white font-semibold rounded-full transition duration-300"
          >
            Send <FiSend size={18} />
          </button>
        </form>
      </motion.div>
    </div>
  );
};

export default Contact;
