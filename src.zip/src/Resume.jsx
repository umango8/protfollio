// src/components/Resume.jsx
import { motion } from "framer-motion";
import { FaDownload } from "react-icons/fa";

const Resume = () => {
  return (
    <div id="resume" className="w-full py-20 px-6 bg-gradient-to-b from-black to-gray-900 text-white">
      <motion.div
        className="max-w-3xl mx-auto text-center"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h2 className="text-4xl font-bold text-purple-400 mb-6">My Resume</h2>
        <p className="mb-6 text-gray-300">
          Want to know more about my education, skills, and work experience? Download my full resume below.
        </p>
        <a
          href="/resume.pdf"
          download
          className="inline-flex items-center gap-3 px-6 py-3 bg-purple-600 hover:bg-purple-700 transition duration-300 rounded-full text-white font-semibold shadow-lg"
        >
          <FaDownload /> Download Resume
        </a>
      </motion.div>
    </div>
  );
};

export default Resume;
