// src/components/ProjectModal.jsx
import { motion } from "framer-motion";

const Modal = ({ project, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 px-4">
      <motion.div
        className="bg-gray-900 rounded-xl p-6 max-w-lg text-white"
        initial={{ scale: 0.7, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
      >
        <h2 className="text-2xl font-bold text-purple-400 mb-4">{project.title}</h2>
        <p className="mb-6 text-gray-300">{project.about}</p>
        <button
          onClick={onClose}
          className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-full"
        >
          Close
        </button>
      </motion.div>
    </div>
  );
};

export default Modal;
