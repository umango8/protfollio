import { useState } from "react";
import { FaBars, FaTimes } from "react-icons/fa";

const Navbar = () => {
  const [nav, setNav] = useState(false);
  const links = ["About", "Skills", "Projects", "Resume", "Contact"];

  return (
    <div className="fixed w-full z-50 bg-black bg-opacity-80 p-4 flex justify-between items-center">
      <h1 className="text-2xl font-bold">Umang.dev</h1>
      <ul className="hidden md:flex gap-6">
        {links.map((link) => (
          <li key={link} className="hover:text-purple-400 duration-200 cursor-pointer">
            <a href={`#${link.toLowerCase()}`}>{link}</a>
          </li>
        ))}
      </ul>
      <div className="md:hidden z-50" onClick={() => setNav(!nav)}>
        {nav ? <FaTimes size={24} /> : <FaBars size={24} />}
      </div>
      {nav && (
        <ul className="absolute top-16 left-0 w-full bg-black bg-opacity-90 p-4 flex flex-col items-center gap-4">
          {links.map((link) => (
            <li
              key={link}
              className="text-xl hover:text-purple-400 duration-200 cursor-pointer"
              onClick={() => setNav(false)}
            >
              <a href={`#${link.toLowerCase()}`}>{link}</a>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Navbar;