// src/components/Projects.jsx
import { useState } from "react";
import { motion } from "framer-motion";
import { FaGithub } from "react-icons/fa";
import Modal from "./ProjectModal"; // we'll create this next
import project1 from "../public/1725.jpg";
import project2 from "../public/project2.jpg";
import project3 from "../public/project3.jpg";

const projectData = [
  {
    title: "GlamCart",
    image: project1,
    code: "https://github.com/your-username/glamcart",
    about: "A fashion eCommerce site built with HTML, CSS, and JavaScript featuring a sleek dark UI and smooth animations.",
  },
  {
    title: "QuickHire",
    image: project2,
    code: "https://github.com/your-username/quickhire",
    about: "A job portal built using the MERN stack with employer and employee login, smart filtering, and instant application alerts.",
  },
  {
    title: "Portfolio Site",
    image: project3,
    code: "https://github.com/your-username/portfolio",
    about: "My personal portfolio to showcase my skills, built using React and Tailwind with Framer Motion animations.",
  },
];

const Projects = () => {
  const [modalData, setModalData] = useState(null);

  return (
    <div id="projects" className="w-full py-20 px-6 bg-black text-white relative overflow-hidden">
      <h2 className="text-3xl md:text-4xl font-bold text-purple-400 text-center mb-10">My Projects</h2>

      {/* Continuous scrolling screenshots */}
      <div className="overflow-hidden whitespace-nowrap mb-16">
        <div className="animate-scroll inline-block space-x-10">
          {projectData.map((proj, idx) => (
            <img
              key={idx}
              src={proj.image}
              alt={proj.title}
              className="inline-block w-72 h-44 object-cover rounded-lg border border-gray-700"
            />
          ))}
        </div>
      </div>

      {/* Project Cards */}
      <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto z-10">
        {projectData.map((proj, idx) => (
          <motion.div
            key={idx}
            className="bg-gray-800 rounded-xl p-6 shadow-lg hover:scale-105 transition-transform duration-300"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.2 }}
          >
            <img src={proj.image} alt={proj.title} className="w-full h-40 object-cover rounded-lg mb-4" />
            <h3 className="text-xl font-semibold mb-2">{proj.title}</h3>
            <div className="flex gap-4 mt-4">
              <a
                href={proj.code}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-purple-600 hover:bg-purple-700 text-white py-1 px-4 rounded-full flex items-center gap-2"
              >
                <FaGithub /> View Code
              </a>
              <button
                onClick={() => setModalData(proj)}
                className="bg-gray-700 hover:bg-gray-600 text-white py-1 px-4 rounded-full"
              >
                About
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Modal */}
      {modalData && <Modal project={modalData} onClose={() => setModalData(null)} />}
    </div>
  );
};

export default Projects;
