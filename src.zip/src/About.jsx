// src/components/About.jsx
import { motion } from "framer-motion";
import profile from "../public/project2.jpg"; // Make sure this path is correct

const About = () => {
  return (
    <section
      id="about"
      className="min-h-screen flex flex-col md:flex-row items-center justify-center gap-10 p-10 bg-gradient-to-b from-black to-gray-900"
    >
      <motion.div
        initial={{ x: 100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 1 }}
        className=" md:text-left pb-60 "
      >
       <motion.img
        src={profile}
        alt="Profile"
        initial={{ x: -100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 1 }}
        className="w-72 h-72 md:w-96 md:h-96 object-cover rounded-2xl shadow-lg border-2 border-purple-500"
      />
         <h2 className="text-5xl font-bold pb-20  text-purple-400 ">About Me</h2>
        <p className="text-lg md:text-xl leading-relaxed max-w-xl">
          Hello! I'm <span className="text-purple-400 font-semibold">Umang Singh</span>, a passionate React Developer intern 🚀. I love turning
          creative ideas into reality using code. With strong knowledge in React,
          JavaScript, HTML, CSS, and UI/UX design, I’m always excited to learn
          and build beautiful, performant applications Lorem ipsum dolor sit, amet consectetur adipisicing elit. Consequatur voluptatum quibusdam, eos reiciendis, ut laudantium saepe praesentium amet a quaerat illo aperiam facere rem ab corporis possimus fuga numquam blanditiis!.
        </p>
      </motion.div>
    </section>
  );
};

export default About;
